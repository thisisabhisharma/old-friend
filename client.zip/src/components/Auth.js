import { Component } from "react";

class Auth extends Component {
    constructor(props) {
        super(props);
        this.authenticated = false;
    }



    logout(cb) {
        this.authenticated = false;
        cb();
    }

    isAuthenticated() {
        return this.authenticated;
    }
}

export default new Auth();