import React, { Component } from "react";
// import { register } from "./UserFuntions";
import axios from "axios";
import "./stylesheet.css";

const qs = require("querystring");
const BASE_LINK = "https://project.harshitaapptech.com/oldschool/server/api/";

const initialState = {
  name: "",
  email: "",
  password: "",
  nameError: "",
  emailError: "",
  passwordError: "",
};

class RegisterScreen extends Component {
  constructor(props) {
    super(props);

    this.state = initialState;
    console.log(this.state.name + "this is state");
  }

  componentDidMount() {
    console.log(this.state);
  }

  componentDidUpdate() {
    console.log(this.state);
  }

  validate = () => {
    let emailError = "";
    let nameError = "";
    let passwordError = "";

    if (!this.state.email.includes("@")) {
      emailError = "invalid email";
    }
    if (!this.state.name) {
      nameError = "name cannot be blank";
    }
    if (!this.state.password) {
      passwordError = "password must be alteast of 8 character";
    }
    if (emailError || nameError || passwordError) {
      this.setState({ emailError, nameError, passwordError });
      return false;
    }
    return true;
  };

  changeHandler = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  };

  onSubmit = (e) => {
    e.preventDefault();
    const isValid = this.validate();
    if (isValid) {
      console.log(this.state);
      this.setState(initialState);
    }
    // console.log("this is on submit state" + this.state);
    const newUser = {
      name: this.state.name,
      email: this.state.email,
      password: this.state.password,
    };
    const config = {
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
    };
    axios
      .post(BASE_LINK + `users/register`, qs.stringify(newUser), config)
      .then((res) => {
        console.log(res.data);
      });
  };

  render() {
    const { name, email, password } = this.state;
    return (
      <div className="outer-div">
        <div className="left-div"></div>
        <label></label>
        <div className="right-div">
          <p className="welcomeText">WELCOME</p>
          <form onSubmit={this.onSubmit}>
            <input
              className="userInput"
              type="text"
              name="name"
              placeholder="Name"
              value={name}
              onChange={this.changeHandler}
            ></input>
            <div style={{ fontSize: 12, color: "red" }}>
              {this.state.nameError}
            </div>
            <input
              className="userInput"
              type="text"
              name="email"
              placeholder="Email"
              value={email}
              onChange={this.changeHandler}
            ></input>
            <div style={{ fontSize: 12, color: "red" }}>
              {this.state.emailError}
            </div>
            <input
              className="userInput"
              type="text"
              name="password"
              placeholder="Password"
              value={password}
              onChange={this.changeHandler}
            ></input>
            <div style={{ fontSize: 12, color: "red" }}>
              {this.state.passwordError}
            </div>
            <button className="continue" type="submit">
              Register
            </button>

            <p className="textColor">
              By clicking continue you are accepting our terms and conditions
            </p>
            <a href="/">Back to Login?</a>
          </form>
        </div>
      </div>
    );
  }
}

export default RegisterScreen;
