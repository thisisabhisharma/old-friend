import React, { Component } from "react";
import "./stylesheet.css";
import axios from "axios";
import { Link, Redirect } from "react-router-dom";
// import Auth from "./Auth";
import Cookies from "js-cookie";

const qs = require("querystring");

const BASE_LINK = "https://project.harshitaapptech.com/oldschool/server/api/";

function LoginScreen()  {
   
    const token = Cookies.get("token");
    let loggedIn = true;
    if (token == null) {
      loggedIn = false;
      console.log("LOGIN if loggedin state: " + loggedIn);
    }
    this.state = {
      email: "",
      password: "",
      token: "",
      loggedIn,
    };
  }

  componentDidMount() {
    console.log("onMount");
    console.log(this.state);
  }

  componentDidUpdate() {
    // console.log("component did update :");
    console.log(this.state);
  }

  changeHandler = (e) => {
    this.setState({ [e.target.name]: e.target.value });
  };

  onSubmit = (e) => {
    e.preventDefault();
    // console.log("this is on submit state" + this.state);
    const user = {
      email: this.state.email,
      password: this.state.password,
    };
    const config = {
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
    };
    axios
      .post(BASE_LINK + `users/login`, qs.stringify(user), config)
      .then((res) => {
        this.setState({
          token: res.data.token,
        });
        console.log(res.data);
        if (this.state.token == null) {
          console.log("input validation");
        } else {
          Cookies.set("token", this.state.token);
        }
        console.log(this.state);
        this.login();
      })
      .catch((err) => {
        if (err.response) {
          console.log("error in response " + err.response);
        } else if (err.request) {
          console.log("error in request " + err.request);
        } else {
          console.log(err);
        }
      });
  };

  login() {
    console.log("inside login()");
    const token = Cookies.get("token");
    console.log("inside login token log :" + token);
    if (token == null) {
      this.setState(
        {
          loggedIn: false,
        },
        () => {
          console.log("token is null, loggedIn value: ", this.state.loggedIn);
        }
      );
    } else {
      this.setState(
        {
          loggedIn: true,
        },
        () => {
          console.log("inside else " + this.state.loggedIn);
        }
      );
    }
  }

  register() {
    // let history = useHistory();
    console.log("register() called");
    // history.push("/register");
    return <Link to="/register"></Link>;
  }

  isAuthenticated() {
    return this.authenticated;
  }

  render() {
    if (this.state.loggedIn) {
      console.log("login redirect called");
      return <Redirect to="/home" />;
    }
    console.log("LOGIN render");
    const { email, password } = this.state;
    // const classes = useStyles();
    // console.log(classes);
    return (
      <div className="outer-div">
        <div className="left-div"></div>
        <label></label>
        <div className="right-div">
          <p className="welcomeText">WELCOME</p>
          <form className="loginForm" onSubmit={this.onSubmit}>
            <input
              className="userInput"
              type="text"
              name="email"
              id="number"
              placeholder="Email"
              value={email}
              onChange={this.changeHandler}
              // error
              // helperText="some validation error"
            />
            <input
              className="userInput"
              type="text"
              name="password"
              id="number"
              placeholder="Password"
              value={password}
              onChange={this.changeHandler}
            />
            <button className="continue" type="submit" onClick={this.onSubmit}>
              Login
            </button>
            <a href="/register">Create New Account</a>

            <p className="textColor">
              By clicking continue you are accepting our terms and conditions
            </p>
          </form>
        </div>
      </div>
    );
  }
}

export default LoginScreen;
