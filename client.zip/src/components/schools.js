import React from "react";
import "./stylesheet.css";

const Schools = (props) => (
  <div className="outer-schoolList">
    <div className="schoolImage">
      <p className="schoolImageText">{props.school_name.charAt(0)}</p>
    </div>
    <div className="schoolList">
      <p className="school_name_p">{props.school_name}</p>
      <p className="school_address_p">{props.school_address}</p>
    </div>
  </div>
);

export default Schools;
