import React from "react";
import "./stylesheet.css";

const userProfile = (props) => (
  <div className="outer-userProfile">
    <div className="userProfileInfo">
      <img src={props.profile_picture} className="userProfileImage" alt="userProfileImage"></img>
      <p className="userProfileInput">{props.name}</p>
      <p className="userProfileInput">{props.email}</p>
    </div>
  </div>
);

export default userProfile;
