import React, { Component } from "react";
import { Link, Redirect } from "react-router-dom";
import "./stylesheet.css";
import axios from "axios";
import Schools from "./schools";
import UserProfile from "./UserProfile";
import SearchSchool from "./search_school";
// import Auth from './Auth';
import Cookies from "js-cookie";
import UserSetting from './UserSetting';

const BASE_LINK = "https://project.harshitaapptech.com/oldschool/server/api/";
const qs = require("querystring");
const token = Cookies.get("token");
let loggedIn = false;

class HomeScreen extends Component {
  constructor(props) {
    super(props);

    if (token == null) {
      loggedIn = false;
      console.log("HOME if loggedin state: " + loggedIn);
    }

    this.state = {
      schools: [],
      userProfile: {},
      searchResult: [],
      input: "",
      loggedIn,
      seen: false,
    };
  }

  componentDidMount() {
    console.log("did mount call");
    // console.log("this is on submit state" + this.state);
    const config = {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    };
    // const token = Cookies.get("token");
    if (token != null) {
      loggedIn = true;
      axios.get(BASE_LINK + `getallschool/`, config).then((res) => {
        // const schools = response.data.slice(0, 4);
        console.log('schools ' , res.data);
        this.setState({ schools: res.data.data });
      });

      axios.get(BASE_LINK + `users/9`, config).then((res) => {
        console.log('userprofile ' , res.data.data);
        this.setState({ userProfile: res.data.data });
      });
    }
  }

  changeHandler = (e) => {
    console.log("changeHanndler call");
    this.setState({ [e.target.name]: e.target.value });
  };

  onSubmit = (e) => {
    e.preventDefault();
    // console.log("this is on submit state" + this.state);
    const body = {
      school_name: this.state.input,
    };
    const config = {
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
    };

    axios
      .post(BASE_LINK + `searchschool`, qs.stringify(body), config)
      .then((res) => {
        console.log(res);
        console.log(res.data.data);
        this.setState({ searchResult: res.data.data });
        console.log(this.state.searchResult);
      });
  };

  addSchool = (e) => {};

  logout() {
    Cookies.remove("token");
    console.log("inside logout");
    this.props.history.push("/");
    // this.authenticated = false;
  }

  togglePop = () => {
    this.setState({
     seen: !this.state.seen
    });
  };

  render() {
    if (this.state.loggedIn === false) {
      console.log("redirect to / called");
      return <Redirect to="/" />;
    }
    console.log("home render");
    const { input } = this.state;
    console.log(this.state);

      

    const schoolList = this.state.schools.map((schoolItem) => {
      return (
        <Schools
          key={schoolItem.sid}
          school_name={schoolItem.school_name}
          school_address={schoolItem.school_address}
        />
      );
    });

    const searchResult = this.state.searchResult.map((resultItem) => {
      return (
        <SearchSchool
          key={resultItem.sid}
          school_name={resultItem.school_name}
        />
      );
    });

    return (
      <div className="outer-div">
        <div className="userProfileSlide">
          <div className="userProfileIcons">
            <i className="fas fa-cog"></i>
            <div>
              <div className="btn" onClick={this.togglePop}>
                <button>New User?</button>
              </div>
              {this.state.seen ? <UserSetting toggle={this.togglePop} /> : null}
            </div>
            <i className="fas fa-bell"></i>
          </div>
          <UserProfile 
            key={this.state.userProfile.uid} 
            name={this.state.userProfile.name} 
            email={this.state.userProfile.email} 
            profile_picture={this.state.userProfile.profile_picture}
          />
          {/* <div className="userProfileInfo">
            <img alt="userImage" className="userProfileImage"></img>
            <form>
              <input
                className="userProfileInput"
                type="text"
                name="name"
                id="name"
                placeholder="Name"
                // value={password}
                // onChange={this.changeHandler}
              ></input>
              <input
                className="userProfileInput"
                type="text"
                name="phone"
                id="phone"
                placeholder="+91"
                // value={password}
                // onChange={this.changeHandler}
              ></input>
            </form>
          </div> */}
        </div>
        <div className="outer-homeResults">
          <div className="topHomeResult">
            {/* <h1>This is HomeScreen</h1> */}
            <form onSubmit={this.onSubmit}>
              <input
                className="searchSchoolField"
                type="text"
                name="input"
                id="input"
                placeholder="Find your school/college"
                value={input}
                onChange={this.changeHandler}
              />
              <i
                onClick={this.onSubmit}
                type="submit"
                className="fas fa-search"
              ></i>
            </form>
          </div>
          <div className="outer-results">
            <div className="homeResult">
              <h1 className="resultHeading">Recents</h1>
              <section className="schools">{schoolList}</section>
            </div>
            <div className="homeResult">
              <h1 className="resultHeading">Results</h1>
              <section className="schools">{searchResult}</section>
            </div>
          </div>
          <button onClick={this.addSchool} className="addSchool">
            Add missing school/college
          </button>
        </div>
        <Link
          to
          className="logoutButton"
          onClick={() => {
            this.logout(() => {
              console.log("logoutcalled");
            });
          }}
        >
          Logout
        </Link>
      </div>
    );
  }
}

export default HomeScreen;
