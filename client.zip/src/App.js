import React from "react";

import "./App.css";

// import NavScreen from "./components/Nav";
import HomeScreen from "./components/Home";
import LoginScreen from "./components/Login";
import RegisterScreen from "./components/Register";
// import ProtectedRoute from "./components/ProtectedRoutes";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";

function App() {
  return (
    <Router>
      <div className="App">
        {/* <NavScreen /> */}
        <Switch>
          <Route path="/" exact component={LoginScreen} />
          <Route exact path="/home" component={HomeScreen} />
          <Route path="/register" component={RegisterScreen} />
          <Route path="*" component={() => "404 NOT FOUND"} />
        </Switch>
      </div>
    </Router>
  );
}

export default App;
